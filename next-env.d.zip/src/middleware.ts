import { NextRequest, NextResponse } from "next/server";


export function middleware(request: NextRequest) {
    // const ipAdress =  request.headers.get("CF-Connecting-IP")
    // return NextResponse.redirect(new URL('/home', request.url))
  }
   
