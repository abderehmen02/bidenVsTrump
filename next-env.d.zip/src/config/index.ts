export const appConfig = {
    countryLocalStorageKey : "countrySymbol" ,
    myVotesLocalStorageKey : "myVotes"
}